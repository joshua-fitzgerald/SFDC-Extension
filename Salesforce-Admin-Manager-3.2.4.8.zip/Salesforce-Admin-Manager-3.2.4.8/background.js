'use strict';
function safeSendMessage(message){
  try{ chrome.runtime.sendMessage(message, ()=>{ if(chrome.runtime.lastError){} }); }catch(_){ }
}
async function openForTab(tabId){
  try{
    await chrome.sidePanel.setOptions({ tabId, path: 'sidebar.html', enabled: true });
    await chrome.sidePanel.open({ tabId });
  }catch(_){ }
}
chrome.runtime.onInstalled.addListener(()=>{
  try{
    if(chrome.sidePanel && chrome.sidePanel.setPanelBehavior){
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    }
  }catch(_){ }
});
chrome.action.onClicked.addListener(async (tab)=>{ if(tab && tab.id!=null) await openForTab(tab.id); });
chrome.tabs.onUpdated.addListener((tabId, changeInfo)=>{ if(changeInfo && changeInfo.url) safeSendMessage({ type:'SF_TAB_URL_CHANGED', url: changeInfo.url }); });
chrome.tabs.onActivated.addListener(async ({ tabId })=>{ try{ const tab=await chrome.tabs.get(tabId); safeSendMessage({ type:'SF_TAB_URL_CHANGED', url: tab && tab.url ? tab.url : null }); }catch(_){ } });
function normalizeSfHost(hostname){ if(!hostname) return hostname; if(hostname.endsWith('.lightning.force.com')) return hostname.replace('.lightning.force.com','.my.salesforce.com'); return hostname; }
async function findSfTab(){ const tabs=await chrome.tabs.query({}); return (tabs||[]).find(t=>/salesforce\.com|lightning\.force\.com|my\.salesforce\.com/.test(t.url||'')) || null; }
async function getSidCookieForHost(hostname){ try{ const c=await chrome.cookies.get({ url:`https://${hostname}`, name:'sid' }); return c && c.value ? c.value : null; }catch(_){ return null; } }
async function sfFetch(path, method='GET', body=null){
  const tab=await findSfTab();
  if(!tab || !tab.url) throw new Error('No Salesforce tab found');
  const host=normalizeSfHost(new URL(tab.url).hostname);
  const url = path.startsWith('http') ? path : `https://${host}/services/data/v59.0${path}`;
  const headers={ 'Content-Type':'application/json','Accept':'application/json' };
  const sid=await getSidCookieForHost(host);
  if(sid) headers.Authorization=`Bearer ${sid}`;
  const resp=await fetch(url,{ method, headers, body: body?JSON.stringify(body):undefined, credentials:'include' });
  const text=await resp.text(); let data;
  try{ data=text?JSON.parse(text):null; }catch(_){ data=text; }
  if(!resp.ok){ const msg=(data && ((Array.isArray(data)&&data[0]&&data[0].message)||data.message)) || `HTTP ${resp.status}`; throw new Error(msg); }
  return data;
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
  (async()=>{
    try{
      if(msg && msg.type==='SF_API'){
        const data = await sfFetch(msg.path, msg.method || 'GET', msg.body || null);
        sendResponse({ ok:true, data });
        return;
      }
      sendResponse({ ok:false, error:'Unknown message type' });
    }catch(e){ sendResponse({ ok:false, error:(e&&e.message)?e.message:String(e) }); }
  })();
  return true;
});
