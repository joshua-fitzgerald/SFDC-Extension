'use strict';

// ============================
// Core helpers
// ============================
const $ = (id) => document.getElementById(id);

function dbg(msg, color = '#f59e0b'){
  const p = $('debug-panel');
  if(!p) return;
  const d = document.createElement('div');
  d.className = 'dbg-line';
  d.style.color = color;
  d.textContent = new Date().toLocaleTimeString() + ' — ' + msg;
  p.appendChild(d);
  p.scrollTop = p.scrollHeight;
}

function toast(msg){
  const t = $('toast');
  if(!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

function setConnectionBanner(state, text, step){
  const b = $('connection-banner');
  if(!b) return;
  b.classList.remove('connected','error');
  if(state) b.classList.add(state);
  const ct = $('connection-text');
  const cs = $('connection-step');
  if(ct) ct.textContent = text || '';
  if(cs) cs.textContent = step || '';
}

// ============================
// Salesforce background bridge
// ============================
async function bgMsg(msg){
  return new Promise((resolve, reject) => {
    try{
      chrome.runtime.sendMessage(msg, (resp) => {
        if(chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if(!resp) return reject(new Error('No response'));
        if(!resp.ok) return reject(new Error(resp.error || 'Error'));
        resolve(resp.data);
      });
    }catch(e){
      reject(e);
    }
  });
}

function getOppIdFromUrl(url){
  const u = url || '';
  const m1 = u.match(/\/Opportunity\/([a-zA-Z0-9]{15,18})/);
  if(m1) return m1[1];
  const m2 = u.match(/\/(006[a-zA-Z0-9]{12,15})/);
  if(m2) return m2[1];
  return null;
}

// ============================
// Date/time helpers (local)
// ============================
function localDateYMD(d = new Date()){
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth()+1).padStart(2,'0');
  const dd = String(d.getDate()).padStart(2,'0');
  return `${yyyy}-${mm}-${dd}`;
}

function localTimeHHMM(d = new Date()){
  const hh = String(d.getHours()).padStart(2,'0');
  const mm = String(d.getMinutes()).padStart(2,'0');
  return `${hh}:${mm}`;
}

function setEventDefaultTimes(){
  const end = new Date();
  const start = new Date(end.getTime() - 60*60*1000);
  const endEl = $('event-end-time');
  const startEl = $('event-start-time');
  if(endEl) endEl.value = localTimeHHMM(end);
  if(startEl) startEl.value = localTimeHHMM(start);
}

// ============================
// Config defaults + storage keys
// ============================
const DEFAULT_PSS_CONFIG = {
  options: ['Pipeline','Upside','Commit','Omitted'],
  default: '' // NULL default => show Select…
};

const DEFAULT_TECHWIN_CONFIG = {
  options: ['0%','40%','80%','100%','Partner Driven Deal','No Tech Win Assessment'],
  default: '' // NULL default => show Select…
};

const DEFAULT_ACTIVITYTYPE_CONFIG = {
  options: ['Demo','Evaluation Jumpstart/Trial','Technical Conversation/Opportunity Nurture'],
  defaultTask: '',
  defaultEvent: ''
};

const DEFAULT_TASKSTATUS_CONFIG = {
  options: ['Completed','Not Started','In Progress'],
  defaultTask: '',
  defaultEvent: ''
};

const DEFAULT_SUBJECT_OPTIONS = ['Demo','Trial Kickoff','Trial Check-in','Technical Discussion'];

const KEY_PSS = 'pssForecastConfig';
const KEY_TECHWIN = 'techWinConfig';
const KEY_ACTIVITYTYPE = 'activityTypeConfig';
const KEY_TASKSTATUS = 'taskStatusConfig';
const KEY_SUBJECTS = 'subjectOptions';
const KEY_ACTIVITY_MODE = 'seActivityMode';

// ============================
// One-time migration: clear old stored defaults for PSS + Tech Win
// (keeps option lists)
// ============================
const SETTINGS_SCHEMA_KEY = 'sam_settings_schema_v1';
async function migrateSettingsToSchemaV1(){
  return new Promise((resolve)=>{
    try{
      chrome.storage.local.get([SETTINGS_SCHEMA_KEY, KEY_PSS, KEY_TECHWIN], (res)=>{
        if(res && res[SETTINGS_SCHEMA_KEY] === 1){
          resolve(true);
          return;
        }
        const updates = {};
        if(res[KEY_PSS]){
          const cur = res[KEY_PSS];
          updates[KEY_PSS] = {
            options: Array.isArray(cur.options) && cur.options.length ? cur.options : DEFAULT_PSS_CONFIG.options,
            default: ''
          };
        }
        if(res[KEY_TECHWIN]){
          const cur = res[KEY_TECHWIN];
          updates[KEY_TECHWIN] = {
            options: Array.isArray(cur.options) && cur.options.length ? cur.options : DEFAULT_TECHWIN_CONFIG.options,
            default: ''
          };
        }
        updates[SETTINGS_SCHEMA_KEY] = 1;
        chrome.storage.local.set(updates, ()=>resolve(true));
      });
    }catch(_){
      resolve(false);
    }
  });
}

// ============================
// Generic UI builders
// ============================
function applyDisconnectedLock(message = 'Open a Salesforce Opportunity'){
  // Hide ALL tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.style.display = 'none';
    tab.classList.remove('active');
  });

  // Hide ALL sections
  document.querySelectorAll('.section').forEach(sec => {
    sec.classList.remove('active');
    sec.style.display = 'none';
  });

  // Show warning banner card
  const warn = $('disconnected-warning');
  const msg  = $('disconnected-message');
  if (warn) warn.style.display = '';
  if (msg)  msg.textContent = message;

  // Show large pulsing overlay warning
  const overlay = $('disconnected-overlay');
  if (overlay) overlay.style.display = 'flex';
}

function clearDisconnectedLock(){
  // Restore tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.style.display = '';
  });

  // Restore sections
  document.querySelectorAll('.section').forEach(sec => {
    sec.style.display = '';
  });

  // Force ACTIONS tab + section active
  const actionsTab = document.querySelector('.tab[data-tab="actions"]');
  const actionsSec = $('actions');

  if (actionsTab) actionsTab.classList.add('active');
  if (actionsSec) actionsSec.classList.add('active');

  // Hide warning banner
  const warn = $('disconnected-warning');
  if (warn) warn.style.display = 'none';

  // Hide overlay warning
  const overlay = $('disconnected-overlay');
  if (overlay) overlay.style.display = 'none';
}

function populateSelectWithOptions(selectEl, options, defaultValue, currentValue){
  if(!selectEl) return;
  const opts = Array.isArray(options) ? options.slice() : [];
  if(currentValue && !opts.includes(currentValue)) opts.unshift(currentValue);

  selectEl.innerHTML = '';

  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = 'Select…';
  selectEl.appendChild(placeholder);

  opts.forEach(opt => {
    const o = document.createElement('option');
    o.value = opt;
    o.textContent = opt;
    selectEl.appendChild(o);
  });

  // Apply default only if nothing selected and default is non-empty
  if(selectEl.value === '' && defaultValue && opts.includes(defaultValue)){
    selectEl.value = defaultValue;
  }
}

function buildNoDefaultDropdown(selectEl, options, selectedValue){
  if(!selectEl) return;
  selectEl.innerHTML = '';

  const none = document.createElement('option');
  none.value = '';
  none.textContent = 'No default (show Select…)';
  selectEl.appendChild(none);

  (options || []).forEach(opt => {
    const o = document.createElement('option');
    o.value = opt;
    o.textContent = opt;
    selectEl.appendChild(o);
  });

  selectEl.value = selectedValue || '';
}

// ============================
// Storage helpers
// ============================
function getObj(key, fallback){
  return new Promise(resolve=>{
    try{
      chrome.storage.local.get([key], (res)=>resolve(res?.[key] || fallback));
    }catch(_){
      resolve(fallback);
    }
  });
}

function setObj(key, value){
  return new Promise(resolve=>{
    try{
      chrome.storage.local.set({ [key]: value }, ()=>resolve(true));
    }catch(_){
      resolve(false);
    }
  });
}

// ============================
// Permissions engine
// ============================
const PASSCODE_HASH = '9269c8274c434291025a3e75d0fb478437d409a1fc9f3042e2a41e6e2790b670';
const KEY_PERMISSIONS = 'permissionsConfig';

const DEFAULT_PROFILES = {
  solutionsEngineer: {
    label: 'Solutions Engineer',
    sfProfileMatch: ['Sales Engineer'],
    permissions: {
      attach:           'read',
      pssForecast:      'write',
      pssCloseDate:     'write',
      techWin:          'write',
      createTask:       'write',
      createEvent:      'disabled',
      eventDuration:    'disabled',
      seComments:       'write',
      specialistNotes:  'read',
      'settings.pss':          'read',
      'settings.techWin':      'read',
      'settings.activityTypes':'read',
      'settings.taskStatus':   'read',
      'settings.subjects':     'write',
      'settings.pssDefault':          'write',
      'settings.techWinDefault':      'write',
      'settings.activityTypesDefaults':'write',
      'settings.taskStatusDefault':   'write'
    }
  },
  specialist: {
    label: 'Specialist',
    sfProfileMatch: ['specialist user'],
    permissions: {
      attach:           'read',
      pssForecast:      'write',
      pssCloseDate:     'write',
      techWin:          'read',
      createTask:       'disabled',
      createEvent:      'write',
      eventDuration:    'disabled',
      seComments:       'read',
      specialistNotes:  'write',
      'settings.pss':          'read',
      'settings.techWin':      'disabled',
      'settings.activityTypes':'read',
      'settings.taskStatus':   'read',
      'settings.subjects':     'write',
      'settings.pssDefault':          'write',
      'settings.techWinDefault':      'disabled',
      'settings.activityTypesDefaults':'write',
      'settings.taskStatusDefault':   'write'
    }
  }
};

const PERM_LABELS = [
  { key:'attach',          label:'Attach to Opp' },
  { key:'pssForecast',     label:'PSS Forecast' },
  { key:'pssCloseDate',    label:'PSS Close Date' },
  { key:'techWin',         label:'Tech Win' },
  { key:'createTask',      label:'Create Task' },
  { key:'createEvent',     label:'Create Event' },
  { key:'eventDuration',   label:'Event: SE Call Duration' },
  { key:'seComments',      label:'SE Comments' },
  { key:'specialistNotes', label:'Specialist Notes' },
  { key:'settings.pss',          label:'Settings: PSS Categories' },
  { key:'settings.pssDefault',   label:'Settings: PSS Default' },
  { key:'settings.techWin',      label:'Settings: Tech Win Options' },
  { key:'settings.techWinDefault', label:'Settings: Tech Win Default' },
  { key:'settings.activityTypes', label:'Settings: Activity Types' },
  { key:'settings.activityTypesDefaults', label:'Settings: Activity Type Defaults' },
  { key:'settings.taskStatus',   label:'Settings: Task Status' },
  { key:'settings.taskStatusDefault', label:'Settings: Task Status Default' },
  { key:'settings.subjects',     label:'Settings: Subject Options' }
];

// Element-to-permission mapping (populated once DOM ready)
const PERM_DOM_MAP = {
  attach:      { card:'attach-card', buttons:['attach-opp'], readLabels:['attached-label','not-attached-label'] },
  pssForecast: { card:null, buttons:['update-pss'], selects:['pss-forecast'] },
  pssCloseDate:{ card:null, buttons:['update-pss-close'], inputs:['pss-close-date'] },
  techWin:     { card:'techwin-card', buttons:['update-techwin'], selects:['tech-win'] },
  createTask:  { card:null, cardParentOf:'task-subject', buttons:['create-task'], hideOnDisableOrRead:true },
  createEvent: { card:'event-card', buttons:['create-event'], hideOnDisableOrRead:true },
  eventDuration: { card:'event-duration-wrap' },
  seComments:  { tab:'secomments', section:'secomments', buttons:['update-se-comments'], textareas:['se-comments'] },
  specialistNotes: { tab:'specialist', section:'specialist', buttons:['update-specialist-notes'], textareas:['specialist-notes'] }
};

// Settings blocks: list editors + save buttons (defaults handled separately)
const SETTINGS_PERM_MAP = {
  'settings.pss':          { editors:['pss-list-editor'], saveButtons:['save-pss-settings'] },
  'settings.techWin':      { editors:['techwin-list-editor'], saveButtons:['save-techwin-settings'] },
  'settings.activityTypes':{ editors:['activitytype-list-editor'], saveButtons:['save-activitytype-settings'] },
  'settings.taskStatus':   { editors:['taskstatus-list-editor'], saveButtons:['save-taskstatus-settings'] },
  'settings.subjects':     { editors:['subject-list-editor'], saveButtons:['save-subject-settings'] }
};

// Settings defaults: separate permission controls for each default dropdown
const SETTINGS_DEFAULTS_PERM_MAP = {
  'settings.pssDefault':          { defaults:['pss-default'] },
  'settings.techWinDefault':      { defaults:['techwin-default'] },
  'settings.activityTypesDefaults':{ defaults:['activitytype-default-task','activitytype-default-event'] },
  'settings.taskStatusDefault':   { defaults:['taskstatus-default-task','taskstatus-default-event'] }
};

async function sha256(text){
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

async function getPermissionsConfig(){
  const cfg = await getObj(KEY_PERMISSIONS, null);
  if(cfg && cfg.profiles) return cfg;
  return { profiles: JSON.parse(JSON.stringify(DEFAULT_PROFILES)), override: null };
}

async function savePermissionsConfig(cfg){
  return setObj(KEY_PERMISSIONS, cfg);
}

// ============================
// Permissions schema migrations
// ============================
// Bump PERM_SCHEMA_VERSION when you change DEFAULT_PROFILES and need existing installs updated.
// Add a new migration function for each version bump.
const PERM_SCHEMA_VERSION = 1;
const KEY_PERM_SCHEMA = 'sam_perm_schema';

// Each migration receives the current config and returns the updated config.
// Migrations run in order from (currentVersion + 1) to PERM_SCHEMA_VERSION.
const PERM_MIGRATIONS = {
  // v1: Initial schema — ensures all keys from DEFAULT_PROFILES exist in stored config.
  //     Preserves any values the user has already customised.
  1: (cfg) => {
    for(const [profileKey, defaultProfile] of Object.entries(DEFAULT_PROFILES)){
      // Add any missing profiles
      if(!cfg.profiles[profileKey]){
        cfg.profiles[profileKey] = JSON.parse(JSON.stringify(defaultProfile));
        continue;
      }
      const stored = cfg.profiles[profileKey];
      // Backfill label + sfProfileMatch if missing
      if(!stored.label) stored.label = defaultProfile.label;
      if(!stored.sfProfileMatch) stored.sfProfileMatch = [...defaultProfile.sfProfileMatch];
      // Backfill any missing permission keys with defaults (don't overwrite existing)
      for(const [permKey, permValue] of Object.entries(defaultProfile.permissions)){
        if(!(permKey in stored.permissions)){
          stored.permissions[permKey] = permValue;
        }
      }
    }
    return cfg;
  }

  // ── To add a future migration: ──
  // 1. Add a comma after the closing brace above
  // 2. Bump PERM_SCHEMA_VERSION
  // 3. Add your migration function:
  //
  // ,2: (cfg) => {
  //   for(const profile of Object.values(cfg.profiles)){
  //     if(!('newFeature' in profile.permissions)){
  //       profile.permissions.newFeature = 'read';
  //     }
  //   }
  //   return cfg;
  // }
};

async function migratePermissionsSchema(){
  const currentVersion = await getObj(KEY_PERM_SCHEMA, 0);
  if(currentVersion >= PERM_SCHEMA_VERSION) return; // already up to date

  let cfg = await getPermissionsConfig();
  let v = currentVersion;

  while(v < PERM_SCHEMA_VERSION){
    v++;
    if(PERM_MIGRATIONS[v]){
      dbg(`Running permissions migration v${v}`, '#38bdf8');
      cfg = PERM_MIGRATIONS[v](cfg);
    }
  }

  await savePermissionsConfig(cfg);
  await setObj(KEY_PERM_SCHEMA, PERM_SCHEMA_VERSION);
  dbg(`Permissions schema migrated to v${PERM_SCHEMA_VERSION}`, '#22c55e');
}

function resolveActiveProfile(cfg){
  // If override is set, use it
  if(cfg.override && cfg.profiles[cfg.override]) return cfg.override;
  // Auto-match from SF profile name
  if(currentUserProfileName){
    const lower = currentUserProfileName.toLowerCase().trim();
    for(const [key, profile] of Object.entries(cfg.profiles)){
      const matches = (profile.sfProfileMatch || []).map(s=>s.toLowerCase().trim());
      if(matches.includes(lower)) return key;
    }
  }
  // Fallback: no match — remain in lockdown
  return null;
}

function getActivePermissions(cfg){
  const key = resolveActiveProfile(cfg);
  if(!key || !cfg.profiles[key]){
    // No profile matched — return read-only lockdown
    const readAll = {};
    PERM_LABELS.forEach(({key: k}) => { readAll[k] = 'read'; });
    return readAll;
  }
  return cfg.profiles[key].permissions || {};
}

let activePermissions = {};
let permissionsConfig = null;

async function loadAndApplyPermissions(){
  permissionsConfig = await getPermissionsConfig();

  // Log the resolution process
  const activeKey = resolveActiveProfile(permissionsConfig);
  const profile = activeKey ? permissionsConfig.profiles[activeKey] : null;

  if(permissionsConfig.override && permissionsConfig.profiles[permissionsConfig.override]){
    dbg('Profile override active: ' + permissionsConfig.profiles[permissionsConfig.override].label, '#f59e0b');
  } else if(currentUserProfileName){
    let matched = false;
    for(const [key, p] of Object.entries(permissionsConfig.profiles)){
      const matchList = (p.sfProfileMatch || []).map(s=>s.toLowerCase().trim());
      if(matchList.includes(currentUserProfileName.toLowerCase().trim())){
        dbg('SF Profile "' + currentUserProfileName + '" matched → ' + p.label, '#22c55e');
        matched = true;
        break;
      }
    }
    if(!matched){
      dbg('SF Profile "' + currentUserProfileName + '" did not match any profile — remaining in lockdown', '#fb7185');
    }
  } else {
    dbg('No SF Profile detected — remaining in lockdown', '#fb7185');
  }

  dbg('Active permission profile: ' + (profile ? profile.label : 'LOCKDOWN (read-only)'), '#38bdf8');
  activePermissions = getActivePermissions(permissionsConfig);

  // Load and apply activity mode override for SE
  const savedMode = await getActivityMode();
  const modeEl = $('activity-mode');
  if(modeEl) modeEl.value = savedMode;
  updateActivityModeUi();
  applyActivityModeOverride();

  applyPermissions();
  if(profile){
    dbg('Lockdown lifted — permissions applied', '#22c55e');
  } else {
    dbg('No profile matched — lockdown remains active', '#f59e0b');
  }
}

// Set all permissions to 'read' as a safe lockdown state (used before profile is known)
function applyLockdown(){
  const readAll = {};
  PERM_LABELS.forEach(({key}) => { readAll[key] = 'read'; });
  activePermissions = readAll;
  applyPermissions();
  dbg('Lockdown applied — all fields read-only until profile detected', '#f59e0b');
}

// ============================
// Activity Mode (SE quick toggle)
// ============================
async function getActivityMode(){
  return (await getObj(KEY_ACTIVITY_MODE, 'task')) || 'task';
}

async function setActivityMode(mode){
  return setObj(KEY_ACTIVITY_MODE, mode);
}

function applyActivityModeOverride(){
  // Only applies to Solutions Engineer profile
  if(!permissionsConfig) return;
  const activeKey = resolveActiveProfile(permissionsConfig);
  if(activeKey !== 'solutionsEngineer') return;

  const modeEl = $('activity-mode');
  const mode = modeEl?.value || 'task';

  if(mode === 'task'){
    activePermissions.createTask = 'write';
    activePermissions.createEvent = 'disabled';
    activePermissions.eventDuration = 'disabled';
  } else {
    activePermissions.createTask = 'disabled';
    activePermissions.createEvent = 'write';
    activePermissions.eventDuration = 'write';
  }
}

function updateActivityModeUi(){
  const wrap = $('activity-mode-wrap');
  if(!wrap) return;

  // Only show for Solutions Engineer
  if(!permissionsConfig){
    wrap.style.display = 'none';
    return;
  }
  const activeKey = resolveActiveProfile(permissionsConfig);
  if(activeKey === 'solutionsEngineer'){
    wrap.style.display = '';
  } else {
    wrap.style.display = 'none';
  }
}

async function handleActivityModeChange(){
  const modeEl = $('activity-mode');
  if(!modeEl) return;
  const mode = modeEl.value;
  await setActivityMode(mode);
  dbg('Activity mode changed to: ' + (mode === 'task' ? 'Create Task' : 'Create Event'), '#38bdf8');

  // Re-derive permissions from profile, apply override, then apply to UI
  if(permissionsConfig){
    activePermissions = getActivePermissions(permissionsConfig);
    applyActivityModeOverride();
    applyPermissions();
  }
}

function applyPermissions(){
  // --- Action-level permissions ---
  for(const [permKey, mapping] of Object.entries(PERM_DOM_MAP)){
    const level = activePermissions[permKey] || 'write';

    // Handle tab visibility (seComments, specialistNotes)
    if(mapping.tab){
      const tabEl = document.querySelector(`.tab[data-tab="${mapping.tab}"]`);
      if(tabEl){
        if(level === 'disabled'){
          tabEl.style.display = 'none';
          // If this tab was active, switch to actions
          if(tabEl.classList.contains('active')){
            tabEl.classList.remove('active');
            const sec = $(mapping.section);
            if(sec) sec.classList.remove('active');
            const actionsTab = document.querySelector('.tab[data-tab="actions"]');
            const actionsSec = $('actions');
            if(actionsTab) actionsTab.classList.add('active');
            if(actionsSec) actionsSec.classList.add('active');
          }
        } else {
          tabEl.style.display = '';
        }
      }
    }

    // Handle card visibility
    if(mapping.card){
      const cardEl = $(mapping.card);
      if(cardEl){
        if(level === 'disabled') cardEl.style.display = 'none';
        else if(mapping.hideOnDisableOrRead && level === 'read') cardEl.style.display = 'none';
        else cardEl.style.display = '';
      }
    }

    // For createTask — find parent card dynamically
    if(mapping.cardParentOf){
      const el = $(mapping.cardParentOf);
      const card = el ? el.closest('.card') : null;
      if(card){
        if(level === 'disabled') card.style.display = 'none';
        else if(mapping.hideOnDisableOrRead && level === 'read') card.style.display = 'none';
        else card.style.display = '';
      }
    }

    // Handle buttons
    if(mapping.buttons){
      mapping.buttons.forEach(id=>{
        const el = $(id);
        if(!el) return;
        if(level === 'disabled' || level === 'read') el.style.display = 'none';
        else el.style.display = '';
      });
    }

    // Handle selects (read = disabled attribute)
    if(mapping.selects){
      mapping.selects.forEach(id=>{
        const el = $(id);
        if(!el) return;
        if(level === 'read') el.setAttribute('disabled','disabled');
        else el.removeAttribute('disabled');
      });
    }

    // Handle inputs (read = readonly)
    if(mapping.inputs){
      mapping.inputs.forEach(id=>{
        const el = $(id);
        if(!el) return;
        if(level === 'read'){ el.setAttribute('readonly','readonly'); el.style.pointerEvents='none'; }
        else { el.removeAttribute('readonly'); el.style.pointerEvents=''; }
      });
    }

    // Handle textareas (read = readonly)
    if(mapping.textareas){
      mapping.textareas.forEach(id=>{
        const el = $(id);
        if(!el) return;
        if(level === 'read') el.setAttribute('readonly','readonly');
        else el.removeAttribute('readonly');
      });
    }

    // Attach special: in read mode show status labels but hide button
    if(permKey === 'attach' && level === 'read'){
      // Labels remain visible (they toggle based on attach state), just button hidden (done above)
    }

    // PSS sub-items: hide label + spacers when disabled
    if(permKey === 'pssForecast'){
      // The forecast label, select, spacer, button are at the top of pss-card
      const selEl = $('pss-forecast');
      const lbls = selEl ? [selEl.previousElementSibling] : []; // the .label above select
      if(level === 'disabled'){
        if(selEl) selEl.style.display = 'none';
        lbls.forEach(l=>{ if(l) l.style.display = 'none'; });
        // Hide spacers between forecast and close date
        if(selEl){
          let next = selEl.nextElementSibling;
          while(next && next.tagName !== 'DIV'){
            next = next.nextElementSibling;
          }
          // hide spacer div + button (button already hidden above)
          if(next && next.style) next.style.display = 'none';
        }
      } else {
        if(selEl) selEl.style.display = '';
        lbls.forEach(l=>{ if(l) l.style.display = ''; });
        if(selEl){
          let next = selEl.nextElementSibling;
          while(next && next.tagName !== 'DIV'){
            next = next.nextElementSibling;
          }
          if(next && next.style) next.style.display = '';
        }
      }
    }
    if(permKey === 'pssCloseDate'){
      const inpEl = $('pss-close-date');
      const wrapper = inpEl ? inpEl.closest('label') : null;
      const lbl = wrapper ? wrapper.previousElementSibling : null; // the .label above
      if(level === 'disabled'){
        if(wrapper) wrapper.style.display = 'none';
        if(lbl && lbl.classList.contains('label')) lbl.style.display = 'none';
        // Also hide leading spacer
        if(lbl){
          let prev = lbl.previousElementSibling;
          if(prev && prev.style && prev.style.height) prev.style.display = 'none';
        }
      } else {
        if(wrapper) wrapper.style.display = '';
        if(lbl && lbl.classList.contains('label')) lbl.style.display = '';
        if(lbl){
          let prev = lbl.previousElementSibling;
          if(prev && prev.style && prev.style.height) prev.style.display = '';
        }
      }
    }
  }

  // PSS card: hide entire card only if BOTH pssForecast and pssCloseDate are disabled
  const pssCard = $('pss-card');
  if(pssCard){
    const pssF = activePermissions.pssForecast || 'write';
    const pssC = activePermissions.pssCloseDate || 'write';
    if(pssF === 'disabled' && pssC === 'disabled') pssCard.style.display = 'none';
    else pssCard.style.display = '';
  }

  // --- Settings-level permissions (list editors + save buttons) ---
  for(const [permKey, mapping] of Object.entries(SETTINGS_PERM_MAP)){
    const level = activePermissions[permKey] || 'write';

    // Editors: hide or readonly
    (mapping.editors || []).forEach(id=>{
      const el = $(id);
      if(!el) return;
      if(level === 'disabled'){
        hideSettingsBlock(el);
      } else if(level === 'read'){
        showSettingsBlock(el);
        el.setAttribute('readonly','readonly');
      } else {
        showSettingsBlock(el);
        el.removeAttribute('readonly');
      }
    });

    // Save buttons: controlled by combined logic below (after defaults loop)
    // Just hide initially here; the combined pass will re-show as needed
    (mapping.saveButtons || []).forEach(id=>{
      const el = $(id);
      if(!el) return;
      el.style.display = 'none';
    });
  }

  // --- Settings defaults permissions (separate from list editors) ---
  for(const [permKey, mapping] of Object.entries(SETTINGS_DEFAULTS_PERM_MAP)){
    const level = activePermissions[permKey] || 'write';

    (mapping.defaults || []).forEach(id=>{
      const el = $(id);
      if(!el) return;
      if(level === 'disabled'){
        hideSettingsBlock(el);
      } else if(level === 'read'){
        showSettingsBlock(el);
        el.setAttribute('disabled','disabled');
      } else {
        showSettingsBlock(el);
        el.removeAttribute('disabled');
      }
    });
  }

  // --- Save button visibility: show if EITHER list is 'write' OR default is 'write' ---
  const SAVE_BTN_PERM_PAIRS = {
    'save-pss-settings':          { list:'settings.pss',          def:'settings.pssDefault' },
    'save-techwin-settings':      { list:'settings.techWin',      def:'settings.techWinDefault' },
    'save-activitytype-settings': { list:'settings.activityTypes', def:'settings.activityTypesDefaults' },
    'save-taskstatus-settings':   { list:'settings.taskStatus',   def:'settings.taskStatusDefault' },
    'save-subject-settings':      { list:'settings.subjects',     def:null }
  };
  for(const [btnId, keys] of Object.entries(SAVE_BTN_PERM_PAIRS)){
    const listLevel = activePermissions[keys.list] || 'write';
    const defLevel  = keys.def ? (activePermissions[keys.def] || 'write') : 'disabled';
    const btn = $(btnId);
    if(btn){
      btn.style.display = (listLevel === 'write' || defLevel === 'write') ? '' : 'none';
    }
  }

  // Update active profile label on Settings tab
  const activeProfileEl = $('active-profile');
  if(activeProfileEl){
    if(permissionsConfig){
      const key = resolveActiveProfile(permissionsConfig);
      activeProfileEl.textContent = (key && permissionsConfig.profiles[key]) ? permissionsConfig.profiles[key].label : 'Lockdown (read-only)';
    } else {
      activeProfileEl.textContent = 'Detecting…';
    }
  }

  // Update permissions page UI if open
  updatePermissionsPageUi();
}

// Helper: hide a settings element and its preceding label
function hideSettingsBlock(el){
  if(!el) return;
  el.style.display = 'none';
  // Also hide the .label immediately before
  let prev = el.previousElementSibling;
  while(prev && prev.style && (prev.tagName === 'DIV' && prev.style.height)){
    prev.style.display = 'none';
    prev = prev.previousElementSibling;
  }
  if(prev && prev.classList && prev.classList.contains('label')) prev.style.display = 'none';
}

function showSettingsBlock(el){
  if(!el) return;
  el.style.display = '';
  let prev = el.previousElementSibling;
  while(prev && prev.style && (prev.tagName === 'DIV' && prev.style.height)){
    prev.style.display = '';
    prev = prev.previousElementSibling;
  }
  if(prev && prev.classList && prev.classList.contains('label')) prev.style.display = '';
}

// ============================
// Permissions page UI
// ============================
let permissionsUnlocked = false;
let failedAttempts = 0;
let lockoutUntil = 0;

function showPasscodeModal(){
  const modal = $('passcode-modal');
  if(modal){
    modal.classList.remove('hidden');
    const inp = $('passcode-input');
    if(inp){ inp.value = ''; inp.focus(); }
    const err = $('passcode-error');
    if(err) err.textContent = '';
  }
}

function hidePasscodeModal(){
  const modal = $('passcode-modal');
  if(modal) modal.classList.add('hidden');
}

async function verifyPasscode(){
  const now = Date.now();
  if(now < lockoutUntil){
    const secs = Math.ceil((lockoutUntil - now)/1000);
    const err = $('passcode-error');
    if(err) err.textContent = `Locked out. Try again in ${secs}s`;
    return;
  }

  const inp = $('passcode-input');
  const val = (inp?.value || '').trim();
  if(!val) return;

  const hash = await sha256(val);
  if(hash === PASSCODE_HASH){
    permissionsUnlocked = true;
    failedAttempts = 0;
    hidePasscodeModal();
    openPermissionsPage();
  } else {
    failedAttempts++;
    const lockSecs = Math.min(60, failedAttempts * 15);
    lockoutUntil = Date.now() + lockSecs * 1000;
    const err = $('passcode-error');
    if(err) err.textContent = `Incorrect. Locked for ${lockSecs}s`;
    if(inp) inp.value = '';
  }
}

function openPermissionsPage(){
  if(!permissionsUnlocked) return;
  // Hide all tabs and sections
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
  // Show permissions section
  const sec = $('permissions');
  if(sec) sec.classList.add('active');
  // Update the UI
  updatePermissionsPageUi();
}

function closePermissionsPage(){
  permissionsUnlocked = false;
  const sec = $('permissions');
  if(sec) sec.classList.remove('active');
  // Go back to actions
  const actTab = document.querySelector('.tab[data-tab="actions"]');
  const actSec = $('actions');
  if(actTab) actTab.classList.add('active');
  if(actSec) actSec.classList.add('active');
}

function updatePermissionsPageUi(){
  if(!permissionsConfig) return;
  const activeKey = resolveActiveProfile(permissionsConfig);

  // Auto-detected profile
  const autoEl = $('perm-auto-profile');
  if(autoEl){
    let autoName = 'Unknown';
    if(currentUserProfileName){
      for(const [key, profile] of Object.entries(permissionsConfig.profiles)){
        const matches = (profile.sfProfileMatch || []).map(s=>s.toLowerCase().trim());
        if(matches.includes(currentUserProfileName.toLowerCase().trim())){
          autoName = profile.label;
          break;
        }
      }
    }
    autoEl.textContent = `${autoName} (SF: ${currentUserProfileName || 'unknown'})`;
  }

  // Override select
  const overrideEl = $('perm-override');
  if(overrideEl && overrideEl._built !== true){
    overrideEl.innerHTML = '<option value="">Auto-detect</option>';
    for(const [key, profile] of Object.entries(permissionsConfig.profiles)){
      const o = document.createElement('option');
      o.value = key;
      o.textContent = profile.label;
      overrideEl.appendChild(o);
    }
    overrideEl._built = true;
  }
  if(overrideEl) overrideEl.value = permissionsConfig.override || '';

  // Active profile indicator
  const activeEl = $('perm-active-profile');
  if(activeEl){
    activeEl.textContent = (activeKey && permissionsConfig.profiles[activeKey]) ? permissionsConfig.profiles[activeKey].label : 'Lockdown (read-only)';
  }

  // Permission grid
  buildPermissionsGrid();
}

function buildPermissionsGrid(){
  const container = $('perm-grid');
  if(!container || !permissionsConfig) return;
  container.innerHTML = '';

  const profileKeys = Object.keys(permissionsConfig.profiles);

  // Header
  const hdr = document.createElement('div');
  hdr.className = 'perm-grid-row perm-grid-header';
  hdr.innerHTML = `<div class="perm-grid-cell perm-label-cell">Function</div>` +
    profileKeys.map(k=>`<div class="perm-grid-cell">${permissionsConfig.profiles[k].label}</div>`).join('');
  container.appendChild(hdr);

  // Rows
  PERM_LABELS.forEach(({key, label})=>{
    const row = document.createElement('div');
    row.className = 'perm-grid-row';

    let html = `<div class="perm-grid-cell perm-label-cell">${label}</div>`;
    profileKeys.forEach(pk=>{
      const val = permissionsConfig.profiles[pk].permissions[key] || 'write';
      html += `<div class="perm-grid-cell">
        <select class="perm-select" data-profile="${pk}" data-key="${key}">
          <option value="disabled"${val==='disabled'?' selected':''}>Disabled</option>
          <option value="read"${val==='read'?' selected':''}>Read</option>
          <option value="write"${val==='write'?' selected':''}>Write</option>
        </select>
      </div>`;
    });

    row.innerHTML = html;
    container.appendChild(row);
  });

  // Attach change listeners
  container.querySelectorAll('.perm-select').forEach(sel=>{
    sel.addEventListener('change', ()=>{
      const pk = sel.dataset.profile;
      const key = sel.dataset.key;
      if(permissionsConfig.profiles[pk]){
        permissionsConfig.profiles[pk].permissions[key] = sel.value;
      }
    });
  });
}

async function savePermissions(){
  if(!permissionsConfig) return;
  const ok = await savePermissionsConfig(permissionsConfig);
  if(ok){
    activePermissions = getActivePermissions(permissionsConfig);
    applyActivityModeOverride();
    applyPermissions();
    toast('✅ Permissions saved');
  } else {
    toast('❌ Failed to save permissions');
  }
}

async function resetPermissions(){
  permissionsConfig = { profiles: JSON.parse(JSON.stringify(DEFAULT_PROFILES)), override: null };
  await savePermissionsConfig(permissionsConfig);
  activePermissions = getActivePermissions(permissionsConfig);
  applyActivityModeOverride();
  applyPermissions();
  const overrideEl = $('perm-override');
  if(overrideEl){ overrideEl._built = false; }
  updatePermissionsPageUi();
  updateActivityModeUi();
  toast('✅ Permissions reset to defaults');
}

async function handleOverrideChange(){
  const overrideEl = $('perm-override');
  if(!overrideEl || !permissionsConfig) return;
  permissionsConfig.override = overrideEl.value || null;
  await savePermissionsConfig(permissionsConfig);
  activePermissions = getActivePermissions(permissionsConfig);
  updateActivityModeUi();
  applyActivityModeOverride();
  applyPermissions();
  dbg('Profile override changed to: ' + (permissionsConfig.override || 'auto'), '#38bdf8');
}

// Triple-click on h1 to open permissions
function initPermissionsTrigger(){
  const h1 = document.querySelector('.hdr h1');
  if(!h1) return;
  let clickCount = 0;
  let clickTimer = null;

  h1.addEventListener('click', ()=>{
    clickCount++;
    if(clickTimer) clearTimeout(clickTimer);
    clickTimer = setTimeout(()=>{ clickCount = 0; }, 500);

    if(clickCount >= 3){
      clickCount = 0;
      if(clickTimer) clearTimeout(clickTimer);
      if(permissionsUnlocked){
        openPermissionsPage();
      } else {
        showPasscodeModal();
      }
    }
  });
}

// ============================
// Subject options
// ============================
async function getSubjectOptions(){
  const v = await getObj(KEY_SUBJECTS, null);
  return (Array.isArray(v) && v.length) ? v : DEFAULT_SUBJECT_OPTIONS;
}

async function saveSubjectOptions(list){
  return setObj(KEY_SUBJECTS, list);
}

async function applySubjectOptionsToActions(){
  const list = await getSubjectOptions();
  const dl = $('task-subject-list');
  if(!dl) return;
  dl.innerHTML = '';
  list.forEach(v => {
    const o = document.createElement('option');
    o.value = v;
    dl.appendChild(o);
  });
}

async function loadSubjectSettingsUi(){
  const list = await getSubjectOptions();
  const ta = $('subject-list-editor');
  if(ta) ta.value = list.join('\n');
}

async function saveSubjectSettings(){
  const ta = $('subject-list-editor');
  if(!ta) return;
  const list = ta.value.split('\n').map(v=>v.trim()).filter(Boolean);
  if(!list.length){
    toast('Subject list cannot be empty');
    return;
  }
  const ok = await saveSubjectOptions(list);
  if(!ok){
    toast('❌ Failed to save Subject options');
    return;
  }
  await applySubjectOptionsToActions();
  toast('✅ Subject options saved');
}

// ============================
// PSS Forecast settings
// ============================
async function getPssConfig(){
  const cfg = await getObj(KEY_PSS, DEFAULT_PSS_CONFIG);
  return {
    options: Array.isArray(cfg.options) && cfg.options.length ? cfg.options : DEFAULT_PSS_CONFIG.options,
    default: (typeof cfg.default === 'string') ? cfg.default : ''
  };
}

async function savePssConfig(cfg){
  return setObj(KEY_PSS, cfg);
}

async function applyPssConfigToActions(){
  const cfg = await getPssConfig();
  const sel = $('pss-forecast');
  const current = sel?.value || '';
  populateSelectWithOptions(sel, cfg.options, cfg.default || '', current);
}

async function loadPssSettingsUi(){
  const cfg = await getPssConfig();
  const listEl = $('pss-list-editor');
  const defEl  = $('pss-default');

  if(listEl) listEl.value = cfg.options.join('\n');

  if(defEl){
    buildNoDefaultDropdown(defEl, cfg.options, cfg.default || '');
  }
}

function syncPssDefaultDropdownFromEditor(){
  const listEl = $('pss-list-editor');
  const defEl  = $('pss-default');
  if(!listEl || !defEl) return;

  const options = listEl.value.split('\n').map(v=>v.trim()).filter(Boolean);
  const prev = defEl.value;
  buildNoDefaultDropdown(defEl, options, (prev === '' || options.includes(prev)) ? prev : '');
}

async function savePssSettings(){
  const listEl = $('pss-list-editor');
  const defEl  = $('pss-default');
  if(!listEl || !defEl) return;

  const canWriteList = (activePermissions['settings.pss'] || 'write') === 'write';
  const canWriteDefault = (activePermissions['settings.pssDefault'] || 'write') === 'write';
  if(!canWriteList && !canWriteDefault) return;

  // Start from current saved config
  const existing = await getPssConfig();
  const cfg = { options: existing.options, default: existing.default };

  if(canWriteList){
    const options = listEl.value.split('\n').map(v=>v.trim()).filter(Boolean);
    if(!options.length){
      toast('PSS list cannot be empty');
      return;
    }
    cfg.options = options;
  }
  if(canWriteDefault){
    cfg.default = defEl.value || '';
  }

  const ok = await savePssConfig(cfg);
  if(!ok){
    toast('❌ Failed to save PSS settings');
    return;
  }

  await applyPssConfigToActions();
  toast('✅ PSS settings saved');
}

// ============================
// Tech Win settings
// ============================
async function getTechWinConfig(){
  const cfg = await getObj(KEY_TECHWIN, DEFAULT_TECHWIN_CONFIG);
  return {
    options: Array.isArray(cfg.options) && cfg.options.length ? cfg.options : DEFAULT_TECHWIN_CONFIG.options,
    default: (typeof cfg.default === 'string') ? cfg.default : ''
  };
}

async function saveTechWinConfig(cfg){
  return setObj(KEY_TECHWIN, cfg);
}

async function applyTechWinConfigToActions(){
  const cfg = await getTechWinConfig();
  const sel = $('tech-win');
  const current = sel?.value || '';
  populateSelectWithOptions(sel, cfg.options, cfg.default || '', current);
}

async function loadTechWinSettingsUi(){
  const cfg = await getTechWinConfig();
  const listEl = $('techwin-list-editor');
  const defEl  = $('techwin-default');

  if(listEl) listEl.value = cfg.options.join('\n');
  if(defEl) buildNoDefaultDropdown(defEl, cfg.options, cfg.default || '');
}

function syncTechWinDefaultFromEditor(){
  const listEl = $('techwin-list-editor');
  const defEl  = $('techwin-default');
  if(!listEl || !defEl) return;

  const options = listEl.value.split('\n').map(v=>v.trim()).filter(Boolean);
  const prev = defEl.value;
  buildNoDefaultDropdown(defEl, options, (prev === '' || options.includes(prev)) ? prev : '');
}

async function saveTechWinSettings(){
  const listEl = $('techwin-list-editor');
  const defEl  = $('techwin-default');
  if(!listEl || !defEl) return;

  const canWriteList = (activePermissions['settings.techWin'] || 'write') === 'write';
  const canWriteDefault = (activePermissions['settings.techWinDefault'] || 'write') === 'write';
  if(!canWriteList && !canWriteDefault) return;

  const existing = await getTechWinConfig();
  const cfg = { options: existing.options, default: existing.default };

  if(canWriteList){
    const options = listEl.value.split('\n').map(v=>v.trim()).filter(Boolean);
    if(!options.length){
      toast('Tech Win list cannot be empty');
      return;
    }
    cfg.options = options;
  }
  if(canWriteDefault){
    cfg.default = defEl.value || '';
  }

  const ok = await saveTechWinConfig(cfg);
  if(!ok){
    toast('❌ Failed to save Tech Win settings');
    return;
  }

  await applyTechWinConfigToActions();
  toast('✅ Tech Win settings saved');
}

// ============================
// Activity Types (shared list; separate defaults)
// ============================
async function getActivityTypeConfig(){
  const cfg = await getObj(KEY_ACTIVITYTYPE, DEFAULT_ACTIVITYTYPE_CONFIG);
  return {
    options: Array.isArray(cfg.options) && cfg.options.length ? cfg.options : DEFAULT_ACTIVITYTYPE_CONFIG.options,
    defaultTask: (typeof cfg.defaultTask === 'string') ? cfg.defaultTask : '',
    defaultEvent: (typeof cfg.defaultEvent === 'string') ? cfg.defaultEvent : ''
  };
}

async function saveActivityTypeConfig(cfg){
  return setObj(KEY_ACTIVITYTYPE, cfg);
}

async function applyActivityTypeConfigToActions(){
  const cfg = await getActivityTypeConfig();
  const taskSel = $('task-type');
  const eventSel = $('event-type');
  const curTask = taskSel?.value || '';
  const curEvent = eventSel?.value || '';
  populateSelectWithOptions(taskSel, cfg.options, cfg.defaultTask || '', curTask);
  populateSelectWithOptions(eventSel, cfg.options, cfg.defaultEvent || '', curEvent);
}

async function loadActivityTypeSettingsUi(){
  const cfg = await getActivityTypeConfig();
  const listEl = $('activitytype-list-editor');
  const defTaskEl = $('activitytype-default-task');
  const defEventEl = $('activitytype-default-event');

  if(listEl) listEl.value = cfg.options.join('\n');
  if(defTaskEl) buildNoDefaultDropdown(defTaskEl, cfg.options, cfg.defaultTask || '');
  if(defEventEl) buildNoDefaultDropdown(defEventEl, cfg.options, cfg.defaultEvent || '');
}

function syncActivityTypeDefaultsFromEditor(){
  const listEl = $('activitytype-list-editor');
  const defTaskEl = $('activitytype-default-task');
  const defEventEl = $('activitytype-default-event');
  if(!listEl || !defTaskEl || !defEventEl) return;

  const options = listEl.value.split('\n').map(v=>v.trim()).filter(Boolean);
  const prevTask = defTaskEl.value;
  const prevEvent = defEventEl.value;
  buildNoDefaultDropdown(defTaskEl, options, (prevTask === '' || options.includes(prevTask)) ? prevTask : '');
  buildNoDefaultDropdown(defEventEl, options, (prevEvent === '' || options.includes(prevEvent)) ? prevEvent : '');
}

async function saveActivityTypeSettings(){
  const listEl = $('activitytype-list-editor');
  const defTaskEl = $('activitytype-default-task');
  const defEventEl = $('activitytype-default-event');
  if(!listEl || !defTaskEl || !defEventEl) return;

  const canWriteList = (activePermissions['settings.activityTypes'] || 'write') === 'write';
  const canWriteDefaults = (activePermissions['settings.activityTypesDefaults'] || 'write') === 'write';
  if(!canWriteList && !canWriteDefaults) return;

  const existing = await getActivityTypeConfig();
  const cfg = {
    options: existing.options,
    defaultTask: existing.defaultTask,
    defaultEvent: existing.defaultEvent
  };

  if(canWriteList){
    const options = listEl.value.split('\n').map(v=>v.trim()).filter(Boolean);
    if(!options.length){
      toast('Activity Type list cannot be empty');
      return;
    }
    cfg.options = options;
  }
  if(canWriteDefaults){
    cfg.defaultTask = defTaskEl.value || '';
    cfg.defaultEvent = defEventEl.value || '';
  }

  const ok = await saveActivityTypeConfig(cfg);
  if(!ok){
    toast('❌ Failed to save Activity Types');
    return;
  }

  await applyActivityTypeConfigToActions();
  toast('✅ Activity Type settings saved');
}

// ============================
// Task Status
// ============================
async function getTaskStatusConfig(){
  const cfg = await getObj(KEY_TASKSTATUS, DEFAULT_TASKSTATUS_CONFIG);
  return {
    options: Array.isArray(cfg.options) && cfg.options.length ? cfg.options : DEFAULT_TASKSTATUS_CONFIG.options,
    defaultTask: (typeof cfg.defaultTask === 'string') ? cfg.defaultTask : (typeof cfg.default === 'string' ? cfg.default : ''),
    defaultEvent: (typeof cfg.defaultEvent === 'string') ? cfg.defaultEvent : ''
  };
}

async function saveTaskStatusConfig(cfg){
  return setObj(KEY_TASKSTATUS, cfg);
}

async function applyTaskStatusConfigToActions(){
  const cfg = await getTaskStatusConfig();
  const taskSel = $('task-status');
  const eventSel = $('event-status');
  const curTask = taskSel?.value || '';
  const curEvent = eventSel?.value || '';
  populateSelectWithOptions(taskSel, cfg.options, cfg.defaultTask || '', curTask);
  populateSelectWithOptions(eventSel, cfg.options, cfg.defaultEvent || '', curEvent);
}

async function loadTaskStatusSettingsUi(){
  const cfg = await getTaskStatusConfig();
  const listEl = $('taskstatus-list-editor');
  const defTaskEl = $('taskstatus-default-task');
  const defEventEl = $('taskstatus-default-event');

  if(listEl) listEl.value = cfg.options.join('\n');
  if(defTaskEl) buildNoDefaultDropdown(defTaskEl, cfg.options, cfg.defaultTask || '');
  if(defEventEl) buildNoDefaultDropdown(defEventEl, cfg.options, cfg.defaultEvent || '');
}

function syncTaskStatusDefaultFromEditor(){
  const listEl = $('taskstatus-list-editor');
  const defTaskEl = $('taskstatus-default-task');
  const defEventEl = $('taskstatus-default-event');
  if(!listEl || !defTaskEl || !defEventEl) return;

  const options = listEl.value.split('\n').map(v=>v.trim()).filter(Boolean);
  const prevTask = defTaskEl.value;
  const prevEvent = defEventEl.value;
  buildNoDefaultDropdown(defTaskEl, options, (prevTask === '' || options.includes(prevTask)) ? prevTask : '');
  buildNoDefaultDropdown(defEventEl, options, (prevEvent === '' || options.includes(prevEvent)) ? prevEvent : '');
}

async function saveTaskStatusSettings(){
  const listEl = $('taskstatus-list-editor');
  const defTaskEl = $('taskstatus-default-task');
  const defEventEl = $('taskstatus-default-event');
  if(!listEl || !defTaskEl || !defEventEl) return;

  const canWriteList = (activePermissions['settings.taskStatus'] || 'write') === 'write';
  const canWriteDefault = (activePermissions['settings.taskStatusDefault'] || 'write') === 'write';
  if(!canWriteList && !canWriteDefault) return;

  const existing = await getTaskStatusConfig();
  const cfg = {
    options: existing.options,
    defaultTask: existing.defaultTask,
    defaultEvent: existing.defaultEvent
  };

  if(canWriteList){
    const options = listEl.value.split('\n').map(v=>v.trim()).filter(Boolean);
    if(!options.length){
      toast('Status list cannot be empty');
      return;
    }
    cfg.options = options;
  }
  if(canWriteDefault){
    cfg.defaultTask = defTaskEl.value || '';
    cfg.defaultEvent = defEventEl.value || '';
  }

  const ok = await saveTaskStatusConfig(cfg);
  if(!ok){
    toast('❌ Failed to save Status settings');
    return;
  }

  await applyTaskStatusConfigToActions();
  toast('✅ Status settings saved');
}

// ============================
// Salesforce state + UI
// ============================
let sfUrl = null;
let oppId = null;
let currentUserId = null;
let currentUserProfileName = null;
let primaryContactId = null;
let origPssCloseDate = '';
let origSeComments = '';
let origSpecialistNotes = '';

async function getCurrentUserId(){
  if(currentUserId) return currentUserId;
  const me = await bgMsg({ type:'SF_API', path:'/chatter/users/me?fields=id,name', method:'GET' });
  currentUserId = me?.id || null;
  return currentUserId;
}

async function loadUserProfileName(){
  try{
    const el = $('sf-profile');
    if(el) el.textContent = 'Loading…';

    const userId = await getCurrentUserId();
    if(!userId){
      if(el) el.textContent = 'Unknown';
      currentUserProfileName = null;
      dbg('SF Profile detection: no user ID available', '#f59e0b');
      return;
    }

    dbg('SF User ID resolved: ' + userId, '#38bdf8');

    const soql = `SELECT Profile.Name FROM User WHERE Id='${userId}' LIMIT 1`;
    const q = encodeURIComponent(soql);
    const data = await bgMsg({ type:'SF_API', path:`/query?q=${q}`, method:'GET' });
    const prof = data?.records?.[0]?.Profile?.Name || 'Unknown';
    currentUserProfileName = prof;
    if(el) el.textContent = prof;
    dbg('SF Profile detected: ' + prof, '#22c55e');
  }catch(e){
    const el = $('sf-profile');
    if(el) el.textContent = 'Error';
    currentUserProfileName = null;
    dbg('SF Profile detection failed: ' + e.message, '#fb7185');
  }
}

async function ensureProfileLoaded(force=false){
  try{
    const el = $('sf-profile');
    const uiText = (el?.textContent || '').trim();
    const looksUnloaded = !currentUserProfileName || uiText === '' || uiText === 'Loading…' || uiText === 'Error' || uiText === 'Unknown';
    if(force || looksUnloaded) await loadUserProfileName();
  }catch(_){ }
}

function showAttachedLabel(){
 const btn = $('attach-opp');
 const lbl = $('attached-label');
 const na = $('not-attached-label');
 if(btn) btn.classList.add('hidden');
 if(lbl) lbl.classList.remove('hidden');
 if(na) na.classList.add('hidden');
}

function showAttachButton(){
 const btn = $('attach-opp');
 const lbl = $('attached-label');
 const na = $('not-attached-label');
 if(btn) btn.classList.remove('hidden');
 if(lbl) lbl.classList.add('hidden');
 if(na) na.classList.remove('hidden');
}

// ============================
// Validation
// ============================
function validateTask(){
  const subject = (($('task-subject')?.value) || '').trim();
  const date = $('task-date')?.value;
  const duration = $('task-duration')?.value;
  const type = $('task-type')?.value;
  const btn = $('create-task');
  if(btn) btn.disabled = !(subject && date && duration && type && oppId);
}

function validateTechWin(){
  const btn = $('update-techwin');
  if(btn) btn.disabled = !(oppId && ($('tech-win')?.value));
}

function validatePss(){
  const btn = $('update-pss');
  if(btn) btn.disabled = !(oppId && ($('pss-forecast')?.value));
}

function validatePssClose(){
  const v = $('pss-close-date')?.value || '';
  const btn = $('update-pss-close');
  if(btn) btn.disabled = !(oppId && v !== (origPssCloseDate || ''));
}

function validateSeComments(){
  const v = $('se-comments')?.value || '';
  const dirty = !!(oppId && v !== (origSeComments || ''));
  const btn = $('update-se-comments');
  if(btn) btn.disabled = !dirty;
}
function validateSpecialistNotes(){
 const v = $('specialist-notes')?.value || '';
 const dirty = !!(oppId && v !== (origSpecialistNotes || ''));
 const btn = $('update-specialist-notes');
 if(btn) btn.disabled = !dirty;
}


function timeToMinutes(t){
  if(!t) return NaN;
  const [hh, mm] = t.split(':').map(Number);
  if(Number.isNaN(hh) || Number.isNaN(mm)) return NaN;
  return hh*60 + mm;
}

function validateEvent(){
  const subject = (($('event-subject')?.value) || '').trim();
  const type = $('event-type')?.value;
  const status = $('event-status')?.value;
  const date = $('event-date')?.value;
  const st = $('event-start-time')?.value;
  const et = $('event-end-time')?.value;

  const stM = timeToMinutes(st);
  const etM = timeToMinutes(et);

  // Duration only required if the field is visible
  const durationWrap = $('event-duration-wrap');
  const durationVisible = durationWrap && durationWrap.style.display !== 'none';
  const duration = $('event-duration')?.value;
  const durationOk = !durationVisible || !!duration;

  const ok = !!oppId && !!subject && !!type && !!status && !!date && !!st && !!et && durationOk && !Number.isNaN(stM) && !Number.isNaN(etM) && etM > stM;
  const btn = $('create-event');
  if(btn) btn.disabled = !ok;
}

function syncSharedPair(aId, bId){
  const a = $(aId), b = $(bId);
  if(!a || !b) return;

  const pushA = () => {
    if(b.value !== a.value) b.value = a.value;
    validateTask();
    validateEvent();
  };

  const pushB = () => {
    if(a.value !== b.value) a.value = b.value;
    validateTask();
    validateEvent();
  };

  a.addEventListener('input', pushA);
  a.addEventListener('change', pushA);
  b.addEventListener('input', pushB);
  b.addEventListener('change', pushB);
}

// ============================
// Opp-scoped reset
// ============================
function clearOppScopedUi(){
  try{
    if($('tech-win')) $('tech-win').value = '';
    if($('pss-forecast')) $('pss-forecast').value = '';
    if($('pss-close-date')) $('pss-close-date').value = '';
    if($('se-comments')) $('se-comments').value = '';
    if($('specialist-notes')) $('specialist-notes').value = '';

    origPssCloseDate = '';
    origSeComments = '';
 origSpecialistNotes = '';
    primaryContactId = null;

    if($('team-list')) $('team-list').innerHTML = '';
    if($('activity-list')) $('activity-list').innerHTML = '';

    showAttachButton();

    if($('event-subject')) $('event-subject').value = '';
    if($('event-notes')) $('event-notes').value = '';
    if($('event-date')) $('event-date').value = localDateYMD();

    validateTask(); validateTechWin(); validatePss(); validatePssClose(); validateSeComments(); validateSpecialistNotes(); validateEvent();
  }catch(_){ }
}

// ============================
// Salesforce data loads
// ============================
async function checkAttachState(){
  try{
    if(!oppId) return;
    const userId = await getCurrentUserId();
    if(!userId) return;

    const soql = `SELECT Id FROM OpportunityTeamMember WHERE OpportunityId='${oppId}' AND UserId='${userId}' LIMIT 1`;
    const q = encodeURIComponent(soql);
    const data = await bgMsg({ type:'SF_API', path:`/query?q=${q}`, method:'GET' });

    if(data?.records?.length) showAttachedLabel();
    else showAttachButton();
  }catch(e){
    dbg('attach state err: ' + e.message, '#fb7185');
  }
}

async function attachToOpp(){
  try{
    if(!oppId) return;
    const btn = $('attach-opp');
    if(btn) btn.disabled = true;

    const userId = await getCurrentUserId();
    const soql = `SELECT Id FROM OpportunityTeamMember WHERE OpportunityId='${oppId}' AND UserId='${userId}' LIMIT 1`;
    const q = encodeURIComponent(soql);
    const existing = await bgMsg({ type:'SF_API', path:`/query?q=${q}`, method:'GET' });

    if(existing?.records?.length){
      showAttachedLabel();
      toast('ℹ️ Already attached');
      return;
    }

    await bgMsg({
      type:'SF_API',
      path:'/sobjects/OpportunityTeamMember',
      method:'POST',
      body:{ OpportunityId: oppId, UserId: userId, TeamMemberRole:'Sales Engineer' }
    });

    toast('✅ Attached to Opp');
    showAttachedLabel();
    await loadTeam();
  }catch(e){
    dbg('attach err: ' + e.message, '#fb7185');
    toast('❌ Attach failed');
  }finally{
    const btn = $('attach-opp');
    if(btn) btn.disabled = false;
  }
}

async function updateTechWin(){
  try{
    const v = $('tech-win')?.value;
    if(!oppId || !v) return;
    const btn = $('update-techwin');
    if(btn) btn.disabled = true;

    await bgMsg({
      type:'SF_API',
      path:`/sobjects/Opportunity/${oppId}`,
      method:'PATCH',
      body:{ Tech_Win_Probability__c: v }
    });

    toast('✅ Tech Win updated');
  }catch(e){
    dbg('techwin err: ' + e.message, '#fb7185');
    toast('❌ Tech Win update failed');
  }finally{
    validateTechWin();
  }
}

async function updatePss(){
  try{
    const v = $('pss-forecast')?.value;
    if(!oppId || !v) return;
    const btn = $('update-pss');
    if(btn) btn.disabled = true;

    await bgMsg({
      type:'SF_API',
      path:`/sobjects/Opportunity/${oppId}`,
      method:'PATCH',
      body:{ PSS_Forecast_Category__c: v }
    });

    toast('✅ PSS Forecast updated');
  }catch(e){
    dbg('pss err: ' + e.message, '#fb7185');
    toast('❌ PSS update failed');
  }finally{
    validatePss();
  }
}

async function updatePssCloseDate(){
  try{
    const v = $('pss-close-date')?.value || '';
    if(!oppId) return;
    const btn = $('update-pss-close');
    if(btn) btn.disabled = true;

    await bgMsg({
      type:'SF_API',
      path:`/sobjects/Opportunity/${oppId}`,
      method:'PATCH',
      body:{ PSS_Close_Date__c: v ? v : null }
    });

    toast('✅ PSS Close Date updated');
    origPssCloseDate = v || '';
  }catch(e){
    dbg('pss close err: ' + e.message, '#fb7185');
    toast('❌ PSS Close Date update failed');
  }finally{
    validatePssClose();
  }
}

async function updateSeComments(){
  try{
    const v = $('se-comments')?.value || '';
    if(!oppId) return;
    const btn = $('update-se-comments');
    if(btn) btn.disabled = true;

    await bgMsg({
      type:'SF_API',
      path:`/sobjects/Opportunity/${oppId}`,
      method:'PATCH',
      body:{ SE_Comments__c: v }
    });

    toast('✅ SE Comments updated');
    origSeComments = v || '';
  }catch(e){
    dbg('se comments err: ' + e.message, '#fb7185');
    toast('❌ SE Comments update failed');
  }finally{
    validateSeComments();
  }
}
async function updateSpecialistNotes(){
 try{
 const v = $('specialist-notes')?.value || '';
 if(!oppId) return;
 const btn = $('update-specialist-notes');
 if(btn) btn.disabled = true;
 await bgMsg({
 type:'SF_API',
 path:`/sobjects/Opportunity/${oppId}`,
 method:'PATCH',
 body:{ Specialist_Notes__c: v }
 });
 toast('✅ Specialist Notes updated');
 origSpecialistNotes = v || '';
 }catch(e){
 dbg('specialist notes err: ' + e.message, '#fb7185');
 toast('❌ Specialist Notes update failed');
 }finally{
 validateSpecialistNotes();
 }
}


async function loadTeam(){
  try{
    const soql = `SELECT Id,TeamMemberRole,User.Name,UserId FROM OpportunityTeamMember WHERE OpportunityId='${oppId}' ORDER BY CreatedDate DESC LIMIT 25`;
    const q = encodeURIComponent(soql);
    const data = await bgMsg({ type:'SF_API', path:`/query?q=${q}`, method:'GET' });

    const rows = (data?.records || []).map(r => `${r.User?.Name || r.UserId} — ${r.TeamMemberRole || ''}`).slice(0, 12);
    const el = $('team-list');
    if(el) el.innerHTML = rows.length ? rows.map(x=>`<div>${x}</div>`).join('') : 'No team members found.';
  }catch(e){
    dbg('team err: ' + e.message, '#fb7185');
    const el = $('team-list');
    if(el) el.textContent = 'Unable to load team.';
  }
}

async function loadActivity(){
  try{
    // Fetch Tasks
    const taskSoql = `SELECT Id,Subject,Status,ActivityDate,IsClosed FROM Task WHERE WhatId='${oppId}' ORDER BY ActivityDate DESC NULLS LAST, CreatedDate DESC LIMIT 20`;
    const taskQ = encodeURIComponent(taskSoql);
    const taskData = await bgMsg({ type:'SF_API', path:`/query?q=${taskQ}`, method:'GET' });

    // Fetch Events
    const eventSoql = `SELECT Id,Subject,StartDateTime,Status__c FROM Event WHERE WhatId='${oppId}' ORDER BY StartDateTime DESC NULLS LAST, CreatedDate DESC LIMIT 20`;
    const eventQ = encodeURIComponent(eventSoql);
    const eventData = await bgMsg({ type:'SF_API', path:`/query?q=${eventQ}`, method:'GET' });

    // Combine and sort by date descending
    const tasks = (taskData?.records || []).map(r => ({
      date: r.ActivityDate || '',
      label: `📋 ${r.ActivityDate || ''} — ${r.Subject || ''} (${r.Status || ''}${r.IsClosed ? ' ✓' : ''})`
    }));

    const events = (eventData?.records || []).map(r => {
      const dt = r.StartDateTime ? r.StartDateTime.slice(0,10) : '';
      return {
        date: dt,
        label: `📅 ${dt} — ${r.Subject || ''} (${r.Status__c || ''})`
      };
    });

    const combined = [...tasks, ...events]
      .sort((a, b) => (b.date || '').localeCompare(a.date || ''))
      .slice(0, 25);

    const el = $('activity-list');
    if(el) el.innerHTML = combined.length ? combined.map(x=>`<div>${x.label}</div>`).join('') : 'No activity found.';
  }catch(e){
    dbg('activity err: ' + e.message, '#fb7185');
    const el = $('activity-list');
    if(el) el.textContent = 'Unable to load activity.';
  }
}

async function loadOppFields(){
  const soql = `SELECT Name, Tech_Win_Probability__c, PSS_Forecast_Category__c, PSS_Close_Date__c, SE_Comments__c, Specialist_Notes__c, Primary_Contact__c, Initial_FPARR__c, Ending_FPARR__c, FPARR_Embedded_Upsell__c FROM Opportunity WHERE Id='${oppId}'`;
  const q = encodeURIComponent(soql);
  const data = await bgMsg({ type:'SF_API', path:`/query?q=${q}`, method:'GET' });
  const rec = data?.records?.[0] || {};

  // Primary Contact for Event WhoId
  primaryContactId = rec.Primary_Contact__c || null;
  if(primaryContactId){
    dbg('Primary contact loaded: ' + primaryContactId, '#22c55e');
  } else {
    dbg('No Primary_Contact__c set on this Opportunity', '#f59e0b');
  }

  // Tech Win: Settings list/default, then SF overrides if present
  await applyTechWinConfigToActions();
  const tw = rec.Tech_Win_Probability__c || '';
  if($('tech-win') && tw) $('tech-win').value = tw;

  // PSS: Settings list/default, then SF overrides if present
  await applyPssConfigToActions();
  const pssVal = rec.PSS_Forecast_Category__c || '';
  if($('pss-forecast') && pssVal) $('pss-forecast').value = pssVal;

  const pssClose = rec.PSS_Close_Date__c ? String(rec.PSS_Close_Date__c).slice(0,10) : '';
  if($('pss-close-date')) $('pss-close-date').value = pssClose;
  origPssCloseDate = pssClose;

  const seCom = rec.SE_Comments__c || '';
  if($('se-comments')) $('se-comments').value = seCom;
  origSeComments = seCom;

  const spNotes = rec.Specialist_Notes__c || '';
 if($('specialist-notes')) $('specialist-notes').value = spNotes;
 origSpecialistNotes = spNotes;

// Finance Metrics (Details tab)
  const fparrInitial = rec.Initial_FPARR__c;
  const fparrEnding  = rec.Ending_FPARR__c;
  const fparrUpsell  = rec.FPARR_Embedded_Upsell__c;

  const setText = (id, val) => {
    const el = $(id);
    if (!el) return;
    el.textContent = (val === null || val === undefined || val === '') ? '—' : String(val);
  };

  setText('fparr-initial', fparrInitial);
  setText('fparr-ending',  fparrEnding);
  setText('fparr-upsell',  fparrUpsell);


  validateTechWin(); validatePss(); validatePssClose(); validateSeComments();
}

async function loadContext(){
  try{
    setConnectionBanner(null, 'Checking Salesforce…', '0/4');

    if(!sfUrl || !/salesforce\.com|lightning\.force\.com|my\.salesforce\.com/.test(sfUrl)){
      oppId = null;
      if($('opp-pill')) $('opp-pill').textContent = 'No Salesforce tab';
      setConnectionBanner('error',
        'Not connected: open a Salesforce Opportunity',
        '0/4');
      applyDisconnectedLock('Open a Salesforce Opportunity');
      clearOppScopedUi();
      return
    }

    setConnectionBanner(null, 'Salesforce tab found', '1/4');

    const newOppId = getOppIdFromUrl(sfUrl);
    
    if(!newOppId){
      oppId = null;
      if($('opp-pill')) $('opp-pill').textContent = 'No Opportunity';
      setConnectionBanner('error',
        'Navigate to a Salesforce Opportunity record',
        '2/4');
      applyDisconnectedLock('Navigate to a Salesforce Opportunity');
      clearOppScopedUi();
      return;
    }


    oppId = newOppId;
    const pill = $('opp-pill');
    if(pill) pill.textContent = 'Opportunity';

    setConnectionBanner(null, 'Opportunity detected', '2/4');
    clearDisconnectedLock();
    await loadOppFields();
    await checkAttachState();

    setConnectionBanner(null, 'Loading team & tasks…', '3/4');
    await Promise.all([loadTeam(), loadActivity()]);

    setConnectionBanner('connected', 'Connected to Salesforce', '4/4');
    applyPermissions();
  }catch(e){
    dbg('context err: ' + e.message, '#fb7185');
    setConnectionBanner('error', 'Not connected: ' + e.message, '0/4');
    applyDisconnectedLock('Open a Salesforce Opportunity');
  }
}

// ============================
// Create Task / Event
// ============================
async function createTask(){
  try{
    const subject = (($('task-subject')?.value) || '').trim();
    const type = $('task-type')?.value || '';
    const date = $('task-date')?.value;
    const durationMinutes = Number($('task-duration')?.value);
    const status = $('task-status')?.value || '';
    const notes = (($('task-notes')?.value) || '').trim();

    if(!subject || !type || !date || !durationMinutes || !oppId){
      toast('Please fill Subject, Type, Due Date and Duration');
      return;
    }

    const btn = $('create-task');
    if(btn) btn.disabled = true;

    const body = {
      Subject: subject,
      Type: type,
      ActivityDate: date,
      WhatId: oppId,
      Priority: 'Normal',
      Call_Hour__c: durationMinutes
    };

    if(status) body.Status = status;
    if(notes) body.Description = notes;

    await bgMsg({ type:'SF_API', path:'/sobjects/Task', method:'POST', body });

    toast('✅ Task created');

    // reset
    if($('task-subject')) $('task-subject').value = '';
    if($('task-duration')) $('task-duration').value = '';
    if($('task-notes')) $('task-notes').value = '';

    // reapply defaults from settings (do not hardcode)
    await applyActivityTypeConfigToActions();
    await applyTaskStatusConfigToActions();

    if($('task-date')) $('task-date').value = localDateYMD();

    validateTask();
    await loadContext();
  }catch(e){
    dbg('create task err: ' + e.message, '#fb7185');
    toast('❌ Task create failed');
  }finally{
    validateTask();
  }
}

async function createEvent(){
  try{
    const subject = (($('event-subject')?.value) || '').trim();
    const type = $('event-type')?.value || '';
    const date = $('event-date')?.value;
    const st = $('event-start-time')?.value;
    const et = $('event-end-time')?.value;
    const status = $('event-status')?.value || '';
    const notes = (($('event-notes')?.value) || '').trim();

    // Duration only required if the field is visible (SE profile)
    const durationWrap = $('event-duration-wrap');
    const durationVisible = durationWrap && durationWrap.style.display !== 'none';
    const durationMinutes = durationVisible ? Number($('event-duration')?.value) : 0;

    if(!subject || !type || !status || !date || !st || !et || !oppId){
      toast('Please fill Subject, Type, Status, Event Date, Start Time and End Time');
      return;
    }

    if(durationVisible && !durationMinutes){
      toast('Please select SE Call Duration');
      return;
    }

    const stM = timeToMinutes(st);
    const etM = timeToMinutes(et);
    if(!(etM > stM)){
      toast('End Time must be after Start Time');
      return;
    }

    if(!primaryContactId){
      toast('No Primary Contact set on this Opportunity — cannot create Event');
      dbg('create event blocked: no Primary_Contact__c (WhoId required)', '#fb7185');
      return;
    }

    const btn = $('create-event');
    if(btn) btn.disabled = true;

    const start = new Date(`${date}T${st}:00`);
    const end = new Date(`${date}T${et}:00`);

    const body = {
      Subject: subject,
      Type: type,
      WhatId: oppId,
      WhoId: primaryContactId,
      Status__c: status,
      StartDateTime: start.toISOString(),
      EndDateTime: end.toISOString()
    };

    if(durationVisible && durationMinutes) body.Call_Hour__c = durationMinutes;
    if(notes) body.Description = notes;

    await bgMsg({ type:'SF_API', path:'/sobjects/Event', method:'POST', body });

    toast('✅ Event created');

    if($('event-subject')) $('event-subject').value = '';
    if($('event-notes')) $('event-notes').value = '';
    if($('event-duration')) $('event-duration').value = '';

    // reapply defaults from settings
    await applyActivityTypeConfigToActions();
    await applyTaskStatusConfigToActions();

    validateEvent();
    await loadContext();
  }catch(e){
    dbg('create event err: ' + e.message, '#fb7185');
    toast('❌ Event create failed');
  }finally{
    validateEvent();
  }
}

// ============================
// Seed sfUrl from active tab
// ============================
async function seedSfUrlFromActiveTab(){
  try{
    if(!chrome?.tabs?.query) return;
    const tabs = await new Promise((resolve)=>chrome.tabs.query({ active:true, currentWindow:true }, resolve));
    const u = tabs?.[0]?.url || null;
    if(u){
      sfUrl = u;
      dbg('Seeded sfUrl from active tab', '#22c55e');
    }
  }catch(e){
    dbg('seed sfUrl err: ' + (e?.message || e), '#fb7185');
  }
}

async function handleRefreshClick(){
  try{
    dbg('Refresh clicked — updating times + reloading Salesforce context', '#38bdf8');
    setEventDefaultTimes();
    if($('event-date') && !$('event-date').value) $('event-date').value = localDateYMD();
    if($('task-date') && !$('task-date').value) $('task-date').value = localDateYMD();

    await seedSfUrlFromActiveTab();
    await ensureProfileLoaded(true);

    // Reapply settings-driven lists
    await applyPssConfigToActions();
    await applyTechWinConfigToActions();
    await applyActivityTypeConfigToActions();
    await applyTaskStatusConfigToActions();
    await applySubjectOptionsToActions();

    await loadContext();

    validateTask(); validateEvent();
    toast('↻ Refreshed');
  }catch(e){
    dbg('refresh err: ' + (e?.message || e), '#fb7185');
    toast('❌ Refresh failed');
  }
}

// ============================
// Init
// ============================
async function init(){
  // One-time migration first
  await migrateSettingsToSchemaV1();

  // Lock everything to read-only until SF profile is detected
  applyLockdown();

  // Tabs
  document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', async ()=>{
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.section').forEach(x=>x.classList.remove('active'));
    t.classList.add('active');
    $(t.dataset.tab)?.classList.add('active');

    // Scroll to top
    const wrap = document.querySelector('.wrap');
    if(wrap) wrap.scrollTop = 0;

    if(t.dataset.tab === 'settings'){
      await ensureProfileLoaded(false);
      await loadPssSettingsUi();
      await loadTechWinSettingsUi();
      await loadActivityTypeSettingsUi();
      await loadTaskStatusSettingsUi();
      await loadSubjectSettingsUi();
    }

    // Close permissions page when switching to a normal tab
    const permSec = $('permissions');
    if(permSec) permSec.classList.remove('active');

    // Re-apply permissions after tab switch
    applyPermissions();
  }));

  // Debug toggle
  $('debug-toggle')?.addEventListener('click', ()=>{
    const p = $('debug-panel');
    if(!p) return;
    p.classList.toggle('visible');
    const btn = $('debug-toggle');
    if(btn) btn.textContent = p.classList.contains('visible') ? 'Hide Debug Log' : 'Show Debug Log';
  });

  // Buttons
  $('attach-opp')?.addEventListener('click', attachToOpp);
  $('update-techwin')?.addEventListener('click', updateTechWin);
  $('update-pss')?.addEventListener('click', updatePss);
  $('update-pss-close')?.addEventListener('click', updatePssCloseDate);
  $('update-se-comments')?.addEventListener('click', updateSeComments);
 $('update-specialist-notes')?.addEventListener('click', updateSpecialistNotes);
  $('create-task')?.addEventListener('click', createTask);
  $('create-event')?.addEventListener('click', createEvent);
  $('refresh')?.addEventListener('click', handleRefreshClick);

  // Validation hooks
  $('tech-win')?.addEventListener('change', validateTechWin);
  $('pss-forecast')?.addEventListener('change', validatePss);
  $('pss-close-date')?.addEventListener('input', validatePssClose);
  $('se-comments')?.addEventListener('input', validateSeComments);
 $('specialist-notes')?.addEventListener('input', validateSpecialistNotes);

  $('task-subject')?.addEventListener('input', validateTask);
  $('task-date')?.addEventListener('input', validateTask);
  $('task-duration')?.addEventListener('change', validateTask);
  $('task-type')?.addEventListener('change', validateTask);
  $('task-status')?.addEventListener('change', validateTask);

  $('event-subject')?.addEventListener('input', validateEvent);
  $('event-type')?.addEventListener('change', validateEvent);
  $('event-status')?.addEventListener('change', validateEvent);
  $('event-duration')?.addEventListener('change', validateEvent);
  $('event-date')?.addEventListener('input', validateEvent);
  $('event-start-time')?.addEventListener('input', validateEvent);
  $('event-end-time')?.addEventListener('input', validateEvent);

  // Shared fields
  syncSharedPair('task-subject', 'event-subject');
  syncSharedPair('task-type', 'event-type');
  syncSharedPair('task-status', 'event-status');

  // Settings listeners
  $('save-pss-settings')?.addEventListener('click', savePssSettings);
  $('pss-list-editor')?.addEventListener('input', syncPssDefaultDropdownFromEditor);

  $('save-techwin-settings')?.addEventListener('click', saveTechWinSettings);
  $('techwin-list-editor')?.addEventListener('input', syncTechWinDefaultFromEditor);

  $('save-activitytype-settings')?.addEventListener('click', saveActivityTypeSettings);
  $('activitytype-list-editor')?.addEventListener('input', syncActivityTypeDefaultsFromEditor);

  $('save-taskstatus-settings')?.addEventListener('click', saveTaskStatusSettings);
  $('taskstatus-list-editor')?.addEventListener('input', syncTaskStatusDefaultFromEditor);

  $('save-subject-settings')?.addEventListener('click', saveSubjectSettings);

  // Permissions page listeners
  initPermissionsTrigger();
  $('passcode-submit')?.addEventListener('click', verifyPasscode);
  $('passcode-cancel')?.addEventListener('click', hidePasscodeModal);
  $('passcode-input')?.addEventListener('keydown', (e)=>{ if(e.key==='Enter') verifyPasscode(); });
  $('perm-save')?.addEventListener('click', savePermissions);
  $('perm-reset')?.addEventListener('click', resetPermissions);
  $('perm-close')?.addEventListener('click', closePermissionsPage);
  $('perm-override')?.addEventListener('change', handleOverrideChange);

  // Activity mode toggle (SE only)
  $('activity-mode')?.addEventListener('change', handleActivityModeChange);

  // Listen for URL-change events from background
  chrome.runtime.onMessage.addListener((msg)=>{
    if(msg?.type === 'SF_TAB_URL_CHANGED'){
      sfUrl = msg.url || null;
      dbg('SF_TAB_URL_CHANGED — reloading context', '#38bdf8');
      setEventDefaultTimes();
      setTimeout(()=>{ loadContext(); }, 120);
    }
  });

  // Initialize defaults
  if($('task-date')) $('task-date').value = localDateYMD();
  if($('event-date')) $('event-date').value = localDateYMD();
  setEventDefaultTimes();

  // Populate settings-driven lists BEFORE context load
  await applyPssConfigToActions();
  await applyTechWinConfigToActions();
  await applyActivityTypeConfigToActions();
  await applyTaskStatusConfigToActions();
  await applySubjectOptionsToActions();

  // Seed URL and load profile + context
  await seedSfUrlFromActiveTab();
  await ensureProfileLoaded(false);
  await loadContext();

  // Migrate permissions schema if needed, then load and apply
  await migratePermissionsSchema();
  await loadAndApplyPermissions();

  // Validate
  validateTask(); validateTechWin(); validatePss(); validatePssClose(); validateSeComments(); validateSpecialistNotes(); validateEvent();
}

init();
