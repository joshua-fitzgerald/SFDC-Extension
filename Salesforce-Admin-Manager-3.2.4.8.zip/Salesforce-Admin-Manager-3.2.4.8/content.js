'use strict';
let lastUrl = location.href;
function notify(){
  const href = location.href;
  if(href !== lastUrl){
    lastUrl = href;
    try{ chrome.runtime.sendMessage({ type: 'SF_TAB_URL_CHANGED', url: lastUrl }); }catch(_){ }
  }
}
const pushState = history.pushState;
history.pushState = function(){ pushState.apply(this, arguments); notify(); };
const replaceState = history.replaceState;
history.replaceState = function(){ replaceState.apply(this, arguments); notify(); };
window.addEventListener('popstate', notify);
window.addEventListener('hashchange', notify);
